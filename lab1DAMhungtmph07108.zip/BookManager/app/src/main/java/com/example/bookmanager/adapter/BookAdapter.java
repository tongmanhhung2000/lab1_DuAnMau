package com.example.bookmanager.adapter;

public class BookAdapter {
}
