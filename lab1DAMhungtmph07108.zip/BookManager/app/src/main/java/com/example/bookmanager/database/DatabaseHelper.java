package com.example.bookmanager.database;

public class DatabaseHelper {
}
